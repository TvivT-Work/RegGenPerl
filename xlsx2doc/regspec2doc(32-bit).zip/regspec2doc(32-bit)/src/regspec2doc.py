from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
# from docx.shared import Inches

import xlrd
def read_xls(filename):
    result = {}
    xls_file = xlrd.open_workbook(filename)
    for table in xls_file.sheets():
        result[table.name] = subresult = []
        nrows = table.nrows
        i = 0
        while i < nrows:
            row = table.row_values(i)
            if len(row) < 2 or row[0].lower() != 'register name':
                i += 1
                continue
            obj = {}
            subresult.append(obj)
            obj['name'] = row[1]
            obj['address'] = table.row_values(i + 1)[1]
            obj['bits'] = [None] * 32
            last_slot = 32
            j = i + 3
            while last_slot > 0:
                row = table.row_values(j)
                bits = row[0]
                assert bits.startswith('[') and bits.endswith(']')
                bits = bits[1:-1]
                if ':' in bits:
                    bits_from, bits_to = bits.split(':')
                    bits_from = int(bits_from)
                    bits_to = int(bits_to)
                else:
                    bits_from = bits_to = int(bits)
                assert last_slot - 1 == bits_from
                for k in range(bits_from, bits_to, -1):
                    obj['bits'][k] = bits_to
                obj['bits'][bits_to] = t = {}
                t['name'] = row[1]
                t['rw'] = row[2]
                t['rval'] = str(int(row[3], 16))
                t['desc'] = row[4]
                last_slot = bits_to
                j += 1
            assert all(i is not None for i in obj['bits']), obj['bits']
            i = j
    return result

data_sample = {
    'title' : 'AES控制寄存器',
    'name' : 'AESCR',
    'address' : '0x40013800',
    'bits' : [
        {
            'name': '-', 
            'rw': 'U', 
            'rval': '0',
            'desc': 'xxx',
        },
    ] + [0] * 31,
}

class RowCellsWrapper(object):
    def __init__(self, table):
        self.table = table
        self.row_index = 0
        self.row_cells = table.rows[0].cells

    def next_row(self, count = 1):
        self.row_index += count
        self.row_cells = self.table.rows[self.row_index].cells

    def prev_row(self, count = 1):
        self.row_index -= count
        self.row_cells = self.table.rows[self.row_index].cells

    def append_row(self):
        self.row_index = len(self.table.rows)
        self.row_cells = self.table.add_row().cells

    def set(self, index, text, bold = False):
        p = self.row_cells[index].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run(text).bold = bold

    def merge(self, from_index, to_index):
        for i in range(from_index + 1, to_index + 1):
            self.row_cells[from_index].merge(self.row_cells[i])
        return

def _fill_bits_row(row, bits_start, bits_data):
    row.set(0, '位', bold = True)
    for i in range(1, 9):
        row.set(i, 'Bit%d'%(bits_start + 8 - i))
    row.next_row()
    i = 1
    while i <= 8:
        slot = bits_start + 8 - i
        value = bits_data[slot]
        if type(value) == dict:
            row.set(i, value['name'])
            row.next_row()
            row.set(i, value['rw'] + '-' + value['rval'])
            row.prev_row()
            i += 1
        else:
            slot = value
            j = min(bits_start + 8 - slot, 8)
            assert j >= i
            value = bits_data[value]
            row.set(i, value['name'])
            row.merge(i, j)
            row.next_row()
            row.set(i, value['rw'] + '-' + value['rval'])
            row.merge(i, j)
            row.prev_row()
            i = j + 1
    row.set(0, '位名', bold = True)
    row.next_row()
    row.set(0, '位权限', bold = True)

def create_table1(doc, data):
    table = doc.add_table(rows=14, cols=9)
    table.style = 'TableGrid'

    row = RowCellsWrapper(table)
    row.set(0, '名称', bold = True)
    row.set(1, data['name'], bold = True)
    row.merge(1, 8)

    row.next_row()
    row.set(0, '地址', bold = True)
    row.set(1, data['address'])
    row.merge(1, 8)

    row.next_row()
    _fill_bits_row(row, 24, data['bits'])

    row.next_row()
    _fill_bits_row(row, 16, data['bits'])

    row.next_row()
    _fill_bits_row(row, 8, data['bits'])

    row.next_row()
    _fill_bits_row(row, 0, data['bits'])

def create_table2(doc, data):
    table = doc.add_table(rows=1, cols=3)
    table.style = 'TableGrid'

    row = RowCellsWrapper(table)
    row.set(0, 'Bit', bold = True)
    row.set(1, '助记符', bold = True)
    row.set(2, '功能描述', bold = True)

    slot = 31
    while slot >= 0:
        row.append_row()
        value = data['bits'][slot]
        if type(value) == dict:
            row.set(0, '%d'%(slot))
        else:
            row.set(0, '%d:%d'%(slot, value))
            slot = value
            value = data['bits'][slot]
        row.set(1, value['name'])
        row.set(2, value['desc'])
        slot -= 1
    return

def main(argv):
    filename = argv[0]
    data_sheets = read_xls(filename)
    document = Document()
    for i, j in data_sheets.items():
        document.add_heading(i, 0)
        document.add_paragraph()
        for k in j:
            create_table1(document, k)
            document.add_paragraph()
            create_table2(document, k)
            document.add_paragraph()
    document.save(filename.split('.')[0] + '.gen.docx')

if __name__ == '__main__':
    import sys
    main(sys.argv[1:])
    #main(['fm312_v01.xls'])
