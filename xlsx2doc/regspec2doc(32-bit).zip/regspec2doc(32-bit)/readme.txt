使用32位 pyinstaller工具打包。

src目录下是源代码，源代码依赖python-docx库，可以通过pip python-docx安装。

usage:
    在命令行下执行 run.bat <xxx.xls>
    <xxx.xls> 是转换的excel文件名。


